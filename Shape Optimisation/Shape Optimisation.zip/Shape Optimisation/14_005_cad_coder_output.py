import cadquery as cq
# Generating a workplane for sketch 0
wp_sketch0 = cq.Workplane(cq.Plane(cq.Vector(-0.75, 0.0, -0.75), cq.Vector(1.0, 6.123233995736766e-17, -6.123233995736766e-17), cq.Vector(6.123233995736766e-17, -1.0, 6.123233995736766e-17)))
loop0=wp_sketch0.moveTo(1.5, 0.0).lineTo(1.5, 1.5).lineTo(0.0, 1.5).lineTo(0.0, 0.0).close()
loop1=wp_sketch0.moveTo(0.18947368421052632, 0.18947368421052632).circle(0.06315789473684211)
loop2=wp_sketch0.moveTo(0.18947368421052632, 1.3105263157894738).circle(0.06315789473684211)
loop3=wp_sketch0.moveTo(1.3105263157894738, 0.18947368421052632).circle(0.06315789473684211)
loop4=wp_sketch0.moveTo(1.3105263157894738, 1.3105263157894738).circle(0.06315789473684211)
solid0=wp_sketch0.add(loop0).add(loop1).add(loop2).add(loop3).add(loop4).extrude(0.75)
solid=solid0
# Generating a workplane for sketch 1
wp_sketch1 = cq.Workplane(cq.Plane(cq.Vector(-0.75, 0.0, -0.75), cq.Vector(1.0, 6.123233995736766e-17, -6.123233995736766e-17), cq.Vector(6.123233995736766e-17, -1.0, 6.123233995736766e-17)))
loop5=wp_sketch1.moveTo(1.5, 0.0).lineTo(1.5, 1.5).lineTo(0.0, 1.5).lineTo(0.0, 0.0).close()
loop6=wp_sketch1.moveTo(0.18947368421052632, 0.18947368421052632).circle(0.06315789473684211)
loop7=wp_sketch1.moveTo(0.18947368421052632, 1.3105263157894738).circle(0.06315789473684211)
loop8=wp_sketch1.moveTo(1.3105263157894738, 0.18947368421052632).circle(0.06315789473684211)
loop9=wp_sketch1.moveTo(1.3105263157894738, 1.3105263157894738).circle(0.06315789473684211)
solid1=wp_sketch1.add(loop5).add(loop6).add(loop7).add(loop8).add(loop9).extrude(0.75)
solid=solid.union(solid1)
