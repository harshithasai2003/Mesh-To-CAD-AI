import FreeCAD as App
import Part
import subprocess
import os
import Mesh
import numpy as np



# NOTE



PARAMETER_FILE = r"D:\UBT\Modelling seminar - II\Shape Opti\14_005\14_005_parameterized.py"

STL_FILE = r"D:\UBT\Modelling seminar - II\Shape Opti\14_005\14_005.stl"

STEP_FILE = r"D:\UBT\Modelling seminar - II\Shape Opti\14_005\optimization_temp.step"

GENERATOR = r"D:\UBT\Modelling seminar - II\Shape Opti\14_005\generate_cad.py"




CADQUERY_PYTHON = r"D:\UBT\Modelling seminar - II\Mesh_to_CAD\Scripts\python.exe"



def generate_cad(parameters):

    print("\nGenerating CAD...")
    print("Parameters:", parameters)

    command = [
        CADQUERY_PYTHON,
        GENERATOR,
        PARAMETER_FILE,
        STEP_FILE,
    ]

    command += [str(x) for x in parameters]

    result = subprocess.run(
        command,
        capture_output=True,
        text=True,
        creationflags=subprocess.CREATE_NO_WINDOW
    )

    print(result.stdout)

    if result.returncode != 0:
        print("ERROR while generating CAD:")
        print(result.stderr)
        return False

    return os.path.exists(STEP_FILE)




def load_stl():

    mesh = Mesh.Mesh(STL_FILE)

    faces = []

    for facet in mesh.Facets:
        points = facet.Points

        wire = Part.makePolygon([
            App.Vector(points[0]),
            App.Vector(points[1]),
            App.Vector(points[2]),
            App.Vector(points[0])
        ])

        faces.append(Part.Face(wire))

    shell = Part.makeShell(faces)

    return Part.makeSolid(shell)



def load_step():

    shape = Part.Shape()

    shape.read(STEP_FILE)

    return shape



def get_dimensions(shape):

    bb = shape.BoundBox

    return [
        bb.XLength,
        bb.YLength,
        bb.ZLength
    ]




def get_center(shape):

    bb = shape.BoundBox

    return App.Vector(
        (bb.XMin + bb.XMax) / 2,
        (bb.YMin + bb.YMax) / 2,
        (bb.ZMin + bb.ZMax) / 2
    )



def align_cad(cad, stl):

    cad_dims = get_dimensions(cad)
    stl_dims = get_dimensions(stl)

    print("\nCAD dimensions:", cad_dims)
    print("STL dimensions:", stl_dims)

  

    cad.rotate(
        App.Vector(0, 0, 0),
        App.Vector(1, 0, 0),
        90
    )

    

    cad_center = get_center(cad)
    stl_center = get_center(stl)

    translation = stl_center.sub(cad_center)

    cad.translate(translation)

    print("\nCAD aligned.")

    print("Aligned CAD dimensions:",
          get_dimensions(cad))

    print("CAD center:",
          get_center(cad))

    print("STL center:",
          get_center(stl))

    return cad




def calculate_cost(cad, stl):

    common = cad.common(stl)

    cad_only = cad.cut(stl)
    stl_only = stl.cut(cad)

    vol_cad_only = cad_only.Volume
    vol_stl_only = stl_only.Volume

    stl_volume = stl.Volume

    total_difference = (
        vol_cad_only +
        vol_stl_only
    )

    cost = total_difference / stl_volume

    print("\n-----------------------------")
    print("STL volume:", stl_volume)
    print("CAD volume:", cad.Volume)
    print("CAD only:", vol_cad_only)
    print("STL only:", vol_stl_only)
    print("Total difference:", total_difference)
    print("NORMALIZED COST:", cost)
    print("-----------------------------")

    return cost




def parameters_are_valid(parameters):

    PARAM_0, PARAM_1, PARAM_2, PARAM_3, PARAM_4 = parameters

    if PARAM_0 <= 0:
        return False

    
    if PARAM_1 <= 0:
        return False

   
    if PARAM_4 <= 2 * PARAM_0:
        return False

 
    if PARAM_2 < PARAM_0:
        return False

    if PARAM_3 > PARAM_4 - PARAM_0:
        return False

    if PARAM_2 >= PARAM_3:
        return False

    return True



def evaluate(parameters):

  

    if not parameters_are_valid(parameters):

        print("\nINVALID PARAMETERS")
        print("Parameters:", parameters)
        print("Assigning penalty cost.")

        return 999999.0


  

    success = generate_cad(parameters)

    if not success:

        print("CAD generation failed.")

        return 999999.0


    
    stl = load_stl()

    cad = load_step()

    cad = align_cad(
        cad,
        stl
    )

    cost = calculate_cost(
        cad,
        stl
    )

    return cost


def evolutionary_optimization():

    x0 = np.array([
        0.55,
        5.0,
        2.5,
        13.5,
        15.0
    ], dtype=float)


    lower_bounds = np.array([
        0.66 * 0.80,     # radius
        7.0 * 0.05,      # height
        2.02 * 0.80,     # lower position
        13.98 * 0.80,    # upper position
        16.0 * 0.80      # size
    ])

    upper_bounds = np.array([
        0.66 * 1.20,
        7.0 * 1.95,
        2.02 * 1.20,
        13.98 * 1.20,
        16.0 * 1.20
    ])

    population_size = 10
    generations = 10

    crossover_probability = 0.9
    mutation_probability = 0.3

    eta_c = 5
    eta_m = 10

    rng = np.random.default_rng(42)

    population = rng.uniform(
        lower_bounds,
        upper_bounds,
        size=(population_size, len(x0))
    )

    population[0] = x0

    costs = np.zeros(population_size)

    print("\n===================================")
    print("INITIAL POPULATION")
    print("===================================")

    for i in range(population_size):

        print("\nIndividual", i + 1, "/", population_size)

        costs[i] = evaluate(
            population[i].tolist()
        )

        print("Cost =", costs[i])

    best_index = np.argmin(costs)
    best_parameters = population[best_index].copy()
    best_cost = costs[best_index]


    print("\n===================================")
    print("INITIAL BEST")
    print("===================================")

    print("Parameters:", best_parameters)
    print("Cost:", best_cost)

    for generation in range(generations):

        print("\n\n===================================")
        print("GENERATION", generation + 1, "/", generations)
        print("===================================")


        offspring = []


        while len(offspring) < population_size:

            i = rng.integers(0, population_size)
            j = rng.integers(0, population_size)

            if costs[i] < costs[j]:
                parent1 = population[i].copy()
            else:
                parent1 = population[j].copy()


            i = rng.integers(0, population_size)
            j = rng.integers(0, population_size)

            if costs[i] < costs[j]:
                parent2 = population[i].copy()
            else:
                parent2 = population[j].copy()

            child1 = parent1.copy()
            child2 = parent2.copy()

            if rng.random() < crossover_probability:

                u = rng.random(len(x0))

                beta = np.where(
                    u <= 0.5,
                    (2.0 * u) ** (1.0 / (eta_c + 1.0)),
                    (1.0 / (2.0 * (1.0 - u)))
                    ** (1.0 / (eta_c + 1.0))
                )

                child1 = (
                    0.5
                    * (
                        (1.0 + beta) * parent1
                        + (1.0 - beta) * parent2
                    )
                )

                child2 = (
                    0.5
                    * (
                        (1.0 - beta) * parent1
                        + (1.0 + beta) * parent2
                    )
                )


            child1 = np.clip(
                child1,
                lower_bounds,
                upper_bounds
            )

            child2 = np.clip(
                child2,
                lower_bounds,
                upper_bounds
            )

            for child in [child1, child2]:

                for k in range(len(x0)):

                    if rng.random() < mutation_probability:

                        y = child[k]

                        lb = lower_bounds[k]
                        ub = upper_bounds[k]

                        if ub <= lb:
                            continue

                        delta1 = (
                            (y - lb)
                            / (ub - lb)
                        )

                        delta2 = (
                            (ub - y)
                            / (ub - lb)
                        )

                        r = rng.random()

                        mut_pow = 1.0 / (
                            eta_m + 1.0
                        )

                        if r <= 0.5:

                            xy = 1.0 - delta1

                            val = (
                                2.0 * r
                                + (1.0 - 2.0 * r)
                                * xy ** (eta_m + 1.0)
                            )

                            deltaq = (
                                val ** mut_pow
                                - 1.0
                            )

                        else:

                            xy = 1.0 - delta2

                            val = (
                                2.0 * (1.0 - r)
                                + 2.0 * (r - 0.5)
                                * xy ** (eta_m + 1.0)
                            )

                            deltaq = (
                                1.0
                                - val ** mut_pow
                            )

                        child[k] = np.clip(
                            y + deltaq * (ub - lb),
                            lb,
                            ub
                        )


                offspring.append(child.copy())

                if len(offspring) >= population_size:
                    break


        offspring = np.array(offspring)

        offspring_costs = np.zeros(
            population_size
        )

        for i in range(population_size):

            print(
                "\nGeneration",
                generation + 1,
                "- Individual",
                i + 1,
                "/",
                population_size
            )

            offspring_costs[i] = evaluate(
                offspring[i].tolist()
            )

            print(
                "Cost =",
                offspring_costs[i]
            )


        combined_population = np.vstack(
            (population, offspring)
        )

        combined_costs = np.concatenate(
            (costs, offspring_costs)
        )


        order = np.argsort(
            combined_costs
        )

        selected = order[:population_size]

        population = combined_population[selected]
        costs = combined_costs[selected]

        current_best_index = np.argmin(costs)

        current_best_cost = costs[
            current_best_index
        ]

        if current_best_cost < best_cost:

            best_cost = current_best_cost

            best_parameters = population[
                current_best_index
            ].copy()

        print("\n===================================")
        print(
            "GENERATION",
            generation + 1,
            "RESULT"
        )
        print("===================================")

        print(
            "Best parameters:",
            best_parameters
        )

        print(
            "Best cost:",
            best_cost
        )


    print("\n\n===================================")
    print("OPTIMIZATION FINISHED")
    print("===================================")

    print(
        "Best parameters:",
        best_parameters
    )

    print(
        "Best cost:",
        best_cost
    )

    print("===================================")

    return best_parameters, best_cost

best_parameters, best_cost = evolutionary_optimization()

print("\nFINAL COST =", best_cost)