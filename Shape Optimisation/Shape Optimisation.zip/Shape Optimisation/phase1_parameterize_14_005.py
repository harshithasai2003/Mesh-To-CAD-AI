import re
import ast
import json
from pathlib import Path



INPUT_FILE = Path(r"D:\UBT\Modelling seminar - II\Shape Opti\14_005\14_005_cad_coder_output.py")

OUTPUT_FILE = Path(r"D:\UBT\Modelling seminar - II\Shape Opti\14_005\14_005_parameterized.py")
PARAMETERS_FILE  = Path(r"D:\UBT\Modelling seminar - II\Shape Opti\14_005\14_005_parameters.json")



GEOMETRIC_METHODS = {
    "moveTo",
    "lineTo",
    "circle",
    "extrude",
    "rect",
    "box",
    "cylinder",
    "sphere",
    "hole",
}


IGNORE_VALUES = {
    0.0,
    1.0,
    -1.0,
}




source = INPUT_FILE.read_text(encoding="utf-8")

lines = source.splitlines(keepends=True)




line_offsets = []

offset = 0

for line in lines:
    line_offsets.append(offset)
    offset += len(line)


def absolute_position(lineno, col):
    """
    Convert AST line/column to absolute character position.
    """
    return line_offsets[lineno - 1] + col



tree = ast.parse(source)


replacements = []


def get_numeric_value(node):
   

    # 12.5
    if isinstance(node, ast.Constant):
        if isinstance(node.value, (int, float)):
            return float(node.value)

    # -12.5
    if isinstance(node, ast.UnaryOp):
        if isinstance(node.op, ast.USub):
            if isinstance(node.operand, ast.Constant):
                if isinstance(node.operand.value, (int, float)):
                    return -float(node.operand.value)

    return None




found_values = []


for node in ast.walk(tree):

    if not isinstance(node, ast.Call):
        continue

   
    if isinstance(node.func, ast.Attribute):

        method_name = node.func.attr

        if method_name not in GEOMETRIC_METHODS:
            continue

        for arg_index, arg in enumerate(node.args):

            value = get_numeric_value(arg)

            if value is None:
                continue

         
            if value in IGNORE_VALUES:
                continue

            if abs(value) < 1e-10:
                continue

            found_values.append(
                {
                    "method": method_name,
                    "arg_index": arg_index,
                    "value": value,
                    "lineno": arg.lineno,
                    "col": arg.col_offset,
                    "end_lineno": arg.end_lineno,
                    "end_col": arg.end_col_offset,
                }
            )




value_to_parameter = {}

parameters = {}


for item in found_values:

    value = item["value"]

    if value not in value_to_parameter:

        parameter_name = f"PARAM_{len(value_to_parameter)}"

        value_to_parameter[value] = parameter_name

        parameters[parameter_name] = {
            "value": value,
            "source_method": item["method"],
            "source_argument": item["arg_index"],
        }




for item in found_values:

    value = item["value"]

    parameter_name = value_to_parameter[value]

    start = absolute_position(
        item["lineno"],
        item["col"]
    )

    end = absolute_position(
        item["end_lineno"],
        item["end_col"]
    )

    replacements.append(
        (
            start,
            end,
            parameter_name
        )
    )



replacements.sort(
    key=lambda x: x[0],
    reverse=True
)

parameterized_source = source

for start, end, replacement in replacements:

    parameterized_source = (
        parameterized_source[:start]
        + replacement
        + parameterized_source[end:]
    )



parameter_lines = []

parameter_lines.append(
    "# ============================================================\n"
)

parameter_lines.append(
    "# AUTOMATICALLY EXTRACTED PARAMETERS\n"
)

parameter_lines.append(
    "# ============================================================\n"
)

parameter_lines.append(
    "\n"
)


for name, info in parameters.items():

    parameter_lines.append(
        f"{name} = {info['value']!r}\n"
    )


parameter_lines.append("\n")


parameter_header = "".join(parameter_lines)



source_lines = parameterized_source.splitlines(
    keepends=True
)


insert_index = 0


for i, line in enumerate(source_lines):

    if line.strip().startswith("import "):

        insert_index = i + 1


parameterized_source = (
    "".join(source_lines[:insert_index])
    + "\n"
    + parameter_header
    + "".join(source_lines[insert_index:])
)




OUTPUT_FILE.write_text(
    parameterized_source,
    encoding="utf-8"
)



parameter_data = {
    "source_file": str(INPUT_FILE),
    "parameter_count": len(parameters),
    "parameters": parameters,
}


PARAMETERS_FILE.write_text(
    json.dumps(
        parameter_data,
        indent=4
    ),
    encoding="utf-8"
)



print()
print("=" * 70)
print("CADQUERY PARAMETERIZATION COMPLETE")
print("=" * 70)

print()
print("Input:")
print(" ", INPUT_FILE)

print()
print("Output:")
print(" ", OUTPUT_FILE)

print()
print("Parameters:")
print()

for name, info in parameters.items():

    print(
        f"  {name:12s} = "
        f"{info['value']:<20} "
        f"({info['source_method']} "
        f"argument {info['source_argument']})"
    )

print()
print("Total parameters:", len(parameters))

print()
print("Created:")
print(" ", OUTPUT_FILE)
print(" ", PARAMETERS_FILE)

print()