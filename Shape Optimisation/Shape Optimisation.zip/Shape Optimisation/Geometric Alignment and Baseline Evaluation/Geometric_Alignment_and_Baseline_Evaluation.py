
import FreeCAD
import Part
import Mesh
import math
import os
import itertools
import random
import csv

import numpy as np
import trimesh
from scipy.spatial import cKDTree



stl_path = r"D:\UBT\Modelling seminar - II\Shape Opti\14_005\14_005.stl"
step_path = r"D:\UBT\Modelling seminar - II\Shape Opti\14_005\14_005.step"

output_csv = r"D:\UBT\Modelling seminar - II\Shape Opti\14_005\experiment1_results.csv"

TOLERANCE = 0.1
N_POINTS = 10000
RANDOM_SEED = 42



def bbox_dimensions(shape):
    bb = shape.BoundBox
    return [bb.XLength, bb.YLength, bb.ZLength]


def print_dimensions(label, shape):
    print(label, bbox_dimensions(shape))
    print(label, "center:", shape.BoundBox.Center)


def rotate_shape(shape, angles):
    """Apply rotations about X, then Y, then Z, around origin."""

    x_angle, y_angle, z_angle = angles
    origin = FreeCAD.Vector(0, 0, 0)

    if x_angle:
        shape.rotate(
            origin, FreeCAD.Vector(1, 0, 0), x_angle
        )

    if y_angle:
        shape.rotate(
            origin, FreeCAD.Vector(0, 1, 0), y_angle
        )

    if z_angle:
        shape.rotate(
            origin, FreeCAD.Vector(0, 0, 1), z_angle
        )


def relative_bbox_error(shape, target_dims):
    dims = bbox_dimensions(shape)

    return sum(
        abs(dims[i] - target_dims[i]) /
        max(abs(target_dims[i]), 1e-12)
        for i in range(3)
    )


def shape_to_trimesh(shape, tolerance):
 

    vertices, faces = shape.tessellate(tolerance)

    vertices = np.array(
        [[v.x, v.y, v.z] for v in vertices],
        dtype=float
    )

    faces = np.array(faces, dtype=int)

    mesh = trimesh.Trimesh(
        vertices=vertices,
        faces=faces,
        process=False
    )

    if len(mesh.faces) == 0:
        raise RuntimeError("Tessellation produced no faces.")

    return mesh




print("\n========== STEP 1: LOAD STL ==========")

stl_mesh = Mesh.Mesh(stl_path)

stl_shape = Part.Shape()
stl_shape.makeShapeFromMesh(
    stl_mesh.Topology, TOLERANCE, True
)

if stl_shape.isNull():
    raise RuntimeError("Could not convert STL to a FreeCAD shape.")

print("STL volume:", stl_shape.Volume)
print_dimensions("STL dimensions:", stl_shape)




print("\n========== STEP 2: LOAD STEP ==========")

cad_original = Part.Shape()
cad_original.read(step_path)

if cad_original.isNull():
    raise RuntimeError("Could not load STEP file.")

print("Original STEP volume:", cad_original.Volume)
print_dimensions("Original STEP dimensions:", cad_original)




print("\n========== STEP 3: SCALE FACTOR ==========")

stl_dims = bbox_dimensions(stl_shape)
cad_dims = bbox_dimensions(cad_original)

stl_max = max(stl_dims)
cad_max = max(cad_dims)

if cad_max <= 0 or stl_max <= 0:
    raise RuntimeError("Invalid bounding-box dimensions.")

scale_factor = stl_max / cad_max

print("Uniform scale factor:", scale_factor)




print("\n========== STEP 4: TEMPORARY NORMALIZATION ==========")


cad_normalized = cad_original.copy()
cad_normalized.scale(scale_factor)

print("Normalized STEP volume:", cad_normalized.Volume)
print_dimensions("Normalized STEP dimensions:", cad_normalized)


print("\n========== STEP 5: FIND ORIENTATION ==========")



angles = [0, 90, 180, 270]

best_angles = None
best_error = float("inf")

for x_angle, y_angle, z_angle in itertools.product(
    angles, repeat=3
):
    candidate = cad_normalized.copy()

    rotate_shape(
        candidate,
        (x_angle, y_angle, z_angle)
    )

    error = relative_bbox_error(candidate, stl_dims)

    if error < best_error:
        best_error = error
        best_angles = (x_angle, y_angle, z_angle)

print("Selected rotations (X, Y, Z):", best_angles)
print("Relative bounding-box error:", best_error)


cad_normalized_rotated = cad_normalized.copy()
rotate_shape(cad_normalized_rotated, best_angles)

print_dimensions(
    "Normalized and rotated STEP dimensions:",
    cad_normalized_rotated
)



print("\n========== STEP 6: NORMALIZED VOLUME ==========")

print("Original STEP volume:", cad_original.Volume)
print("Normalized STEP volume:", cad_normalized.Volume)
print("STL reference volume:", stl_shape.Volume)

print(
    "Volume ratio (normalized STEP / STL):",
    cad_normalized.Volume / stl_shape.Volume
    if stl_shape.Volume else float("nan")
)




print("\n========== STEP 7: ORIGINAL-SCALE BASELINE ==========")

cad_baseline = cad_original.copy()


rotate_shape(cad_baseline, best_angles)

print("STEP volume before alignment:", cad_baseline.Volume)

print("\n========== STEP 8: CENTER ALIGNMENT ==========")

stl_center = stl_shape.BoundBox.Center
cad_center = cad_baseline.BoundBox.Center

translation = stl_center.sub(cad_center)

cad_baseline.translate(translation)

print("Translation:")
print("DX:", translation.x)
print("DY:", translation.y)
print("DZ:", translation.z)

print_dimensions("STL:", stl_shape)
print_dimensions("Aligned original-scale STEP:", cad_baseline)


print("\n========== STEP 9: SURFACE SAMPLING ==========")

random.seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)

stl_tri = shape_to_trimesh(stl_shape, TOLERANCE)
cad_tri = shape_to_trimesh(cad_baseline, TOLERANCE)

stl_points, _ = trimesh.sample.sample_surface(
    stl_tri, N_POINTS
)

cad_points, _ = trimesh.sample.sample_surface(
    cad_tri, N_POINTS
)

print("STL sampled points:", len(stl_points))
print("STEP sampled points:", len(cad_points))


print("\n========== STEP 10: DISTANCES ==========")

# STL -> STEP
cad_tree = cKDTree(cad_points)
dist_stl_to_cad, idx_stl_to_cad = cad_tree.query(
    stl_points, k=1
)

# STEP -> STL
stl_tree = cKDTree(stl_points)
dist_cad_to_stl, idx_cad_to_stl = stl_tree.query(
    cad_points, k=1
)

chamfer = 0.5 * (
    np.mean(dist_stl_to_cad) +
    np.mean(dist_cad_to_stl)
)

hausdorff = max(
    np.max(dist_stl_to_cad),
    np.max(dist_cad_to_stl)
)

print("Chamfer distance:", chamfer)
print("Hausdorff distance:", hausdorff)


print("\n========== STEP 11: WORST SAMPLED PAIR ==========")

i = int(np.argmax(dist_stl_to_cad))
j = int(np.argmax(dist_cad_to_stl))

if dist_stl_to_cad[i] >= dist_cad_to_stl[j]:
    point_a = stl_points[i]
    point_b = cad_points[idx_stl_to_cad[i]]
    max_distance = dist_stl_to_cad[i]
    direction = "STL -> STEP"
else:
    point_a = cad_points[j]
    point_b = stl_points[idx_cad_to_stl[j]]
    max_distance = dist_cad_to_stl[j]
    direction = "STEP -> STL"

print("Direction:", direction)
print("STL point:", point_a)
print("STEP point:", point_b)
print("Maximum sampled distance:", max_distance)

print("\n========== STEP 12: SAVE RESULTS ==========")

results = {
    "STL file": stl_path,
    "STEP file": step_path,
    "Scale factor": scale_factor,
    "Rotation X": best_angles[0],
    "Rotation Y": best_angles[1],
    "Rotation Z": best_angles[2],
    "Bounding-box error": best_error,
    "STL volume": stl_shape.Volume,
    "Original STEP volume": cad_original.Volume,
    "Normalized STEP volume": cad_normalized.Volume,
    "Chamfer": chamfer,
    "Hausdorff": hausdorff,
    "Sample points per mesh": N_POINTS,
    "Random seed": RANDOM_SEED,
    "Tessellation tolerance": TOLERANCE,
}

with open(output_csv, "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["Parameter", "Value"])
    writer.writerows(results.items())

print("Results saved to:", output_csv)

print("\n========== EXPERIMENT 1 COMPLETE ==========")