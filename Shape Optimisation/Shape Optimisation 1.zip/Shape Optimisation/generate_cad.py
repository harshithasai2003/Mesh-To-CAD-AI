import sys
import cadquery as cq


# Arguments
# sys.argv[1] = parameterized CadQuery file
# sys.argv[2] = output STEP file
# sys.argv[3:8] = PARAM_0 ... PARAM_4

parameter_file = sys.argv[1]
step_file = sys.argv[2]

parameters = [float(x) for x in sys.argv[3:8]]

PARAM_0 = parameters[0]
PARAM_1 = parameters[1]
PARAM_2 = parameters[2]
PARAM_3 = parameters[3]
PARAM_4 = parameters[4]


# Execute parameterized CadQuery script

namespace = {
    "PARAM_0": PARAM_0,
    "PARAM_1": PARAM_1,
    "PARAM_2": PARAM_2,
    "PARAM_3": PARAM_3,
    "PARAM_4": PARAM_4,
}

with open(parameter_file, "r", encoding="utf-8") as f:
    code = f.read()

exec(compile(code, parameter_file, "exec"), namespace)


# Get final CadQuery solid

solid = namespace["solid"]


# Export STEP

cq.exporters.export(solid, step_file)

print("STEP generated successfully")
print("Parameters:", parameters)
print("Output:", step_file)