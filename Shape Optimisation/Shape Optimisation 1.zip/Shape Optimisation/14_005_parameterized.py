import cadquery as cq

# AUTOMATICALLY EXTRACTED PARAMETERS

# PARAM_0 = 0.06315789473684211
# PARAM_1 = 0.75
# PARAM_2 = 0.18947368421052632
# PARAM_3 = 1.3105263157894738
# PARAM_4 = 1.5

# PARAM_0 = 0.66
# PARAM_1 = 7.0
# PARAM_2 = 2.02
# PARAM_3 = 13.98
# PARAM_4 = 16.0

# Default values — used only when the file is run directly
PARAM_0 = globals().get("PARAM_0", 0.66)
PARAM_1 = globals().get("PARAM_1", 7.0)
PARAM_2 = globals().get("PARAM_2", 2.02)
PARAM_3 = globals().get("PARAM_3", 13.98)
PARAM_4 = globals().get("PARAM_4", 16.0)

# GEOMETRIC CONSTRAINTS

# Holes must remain completely inside the plate
if PARAM_0 <= 0:
    raise ValueError("PARAM_0 (hole radius) must be positive.")

if PARAM_4 <= 2 * PARAM_0:
    raise ValueError("PARAM_4 (plate size) is too small for the holes.")

if PARAM_2 < PARAM_0:
    raise ValueError("PARAM_2 places the holes outside the plate.")

if PARAM_3 > PARAM_4 - PARAM_0:
    raise ValueError("PARAM_3 places the holes outside the plate.")

# Hole positions must be ordered
if PARAM_2 >= PARAM_3:
    raise ValueError("PARAM_2 must be smaller than PARAM_3.")

# Generating a workplane for sketch 0
wp_sketch0 = cq.Workplane(cq.Plane(cq.Vector(-PARAM_4 / 2, 0.0, -PARAM_4 / 2), cq.Vector(1.0, 6.123233995736766e-17, -6.123233995736766e-17), cq.Vector(6.123233995736766e-17, -1.0, 6.123233995736766e-17)))
loop0=wp_sketch0.moveTo(PARAM_4, 0.0).lineTo(PARAM_4, PARAM_4).lineTo(0.0, PARAM_4).lineTo(0.0, 0.0).close()
loop1=wp_sketch0.moveTo(PARAM_2, PARAM_2).circle(PARAM_0)
loop2=wp_sketch0.moveTo(PARAM_2, PARAM_3).circle(PARAM_0)
loop3=wp_sketch0.moveTo(PARAM_3, PARAM_2).circle(PARAM_0)
loop4=wp_sketch0.moveTo(PARAM_3, PARAM_3).circle(PARAM_0)
solid0=wp_sketch0.add(loop0).add(loop1).add(loop2).add(loop3).add(loop4).extrude(PARAM_1)
solid=solid0
# Generating a workplane for sketch 1
wp_sketch1 = cq.Workplane(cq.Plane(cq.Vector(-PARAM_4 / 2, 0.0, -PARAM_4 / 2), cq.Vector(1.0, 6.123233995736766e-17, -6.123233995736766e-17), cq.Vector(6.123233995736766e-17, -1.0, 6.123233995736766e-17)))
loop5=wp_sketch1.moveTo(PARAM_4, 0.0).lineTo(PARAM_4, PARAM_4).lineTo(0.0, PARAM_4).lineTo(0.0, 0.0).close()
loop6=wp_sketch1.moveTo(PARAM_2, PARAM_2).circle(PARAM_0)
loop7=wp_sketch1.moveTo(PARAM_2, PARAM_3).circle(PARAM_0)
loop8=wp_sketch1.moveTo(PARAM_3, PARAM_2).circle(PARAM_0)
loop9=wp_sketch1.moveTo(PARAM_3, PARAM_3).circle(PARAM_0)
solid1=wp_sketch1.add(loop5).add(loop6).add(loop7).add(loop8).add(loop9).extrude(PARAM_1)
solid=solid.union(solid1)
