import os
import FreeCAD as App
import Part
import Mesh

# SETTINGS

STL_PATH = r"D:\UBT\Modelling seminar - II\Shape Opti\14_005\14_005.stl"

STEP_PATH = r"D:\UBT\Modelling seminar - II\Shape Opti\14_005\14_005.step"

OUTPUT_STEP = r"D:\UBT\Modelling seminar - II\Shape Opti\14_005\14_005_rotated_original_scale.step"

# Rotation selected by your automatic orientation code
ROT_X = 90
ROT_Y = 0
ROT_Z = 90

# Scale factor calculated by your previous script.
# Used ONLY for the temporary visualization copy.
SCALE_FACTOR = 10.666666666666664


# LOAD STL REFERENCE

print("\nLoading STL reference...")

stl_mesh = Mesh.Mesh(STL_PATH)

stl_center = stl_mesh.BoundBox.Center

print("STL dimensions:",
      stl_mesh.BoundBox.XLength,
      stl_mesh.BoundBox.YLength,
      stl_mesh.BoundBox.ZLength)

print("STL center:", stl_center)


# LOAD ORIGINAL STEP

print("\nLoading original STEP...")

original_shape = Part.Shape()
original_shape.read(STEP_PATH)

if original_shape.isNull():
    raise RuntimeError("Could not load original STEP.")

print("Original STEP dimensions:",
      original_shape.BoundBox.XLength,
      original_shape.BoundBox.YLength,
      original_shape.BoundBox.ZLength)


# APPLY SELECTED ROTATION
# Rotation order: X -> Y -> Z

rotated_shape = original_shape.copy()

if ROT_X != 0:
    rotated_shape.rotate(
        App.Vector(0, 0, 0),
        App.Vector(1, 0, 0),
        ROT_X
    )

if ROT_Y != 0:
    rotated_shape.rotate(
        App.Vector(0, 0, 0),
        App.Vector(0, 1, 0),
        ROT_Y
    )

if ROT_Z != 0:
    rotated_shape.rotate(
        App.Vector(0, 0, 0),
        App.Vector(0, 0, 1),
        ROT_Z
    )

print("\nApplied rotation:",
      (ROT_X, ROT_Y, ROT_Z))

print("Rotated dimensions:",
      rotated_shape.BoundBox.XLength,
      rotated_shape.BoundBox.YLength,
      rotated_shape.BoundBox.ZLength)


# CENTER ALIGN ORIGINAL-SCALE STEP TO STL

translation = (
    stl_center.sub(rotated_shape.BoundBox.Center)
)

rotated_shape.translate(translation)

print("\nCenter translation:", translation)


# SAVE ROTATED ORIGINAL-SCALE STEP

if rotated_shape.isNull() or not rotated_shape.isValid():
    raise RuntimeError(
        "Rotated STEP shape is invalid; export cancelled."
    )

save_doc = App.newDocument("RotatedSTEPExport")

save_obj = save_doc.addObject(
    "Part::Feature",
    "RotatedOriginalSTEP"
)

save_obj.Shape = rotated_shape
save_doc.recompute()

Part.export([save_obj], OUTPUT_STEP)

App.closeDocument(save_doc.Name)

print("\nSaved rotated STEP to:")
print(OUTPUT_STEP)


# CREATE VISUALIZATION DOCUMENT

doc = App.newDocument("OrientationCheck")


# STL reference

stl_obj = doc.addObject(
    "Mesh::Feature",
    "STL_Reference"
)

stl_obj.Mesh = stl_mesh

stl_obj.ViewObject.ShapeColor = (0.85, 0.60, 0.15)
stl_obj.ViewObject.Transparency = 65


# Rotated STEP at ORIGINAL scale

original_scale_obj = doc.addObject(
    "Part::Feature",
    "Rotated_STEP_Original_Scale"
)

original_scale_obj.Shape = rotated_shape

original_scale_obj.ViewObject.ShapeColor = (0.1, 0.4, 1.0)
original_scale_obj.ViewObject.Transparency = 0


# Normalized visualization copy
# This copy is NOT exported and is NOT used for distances.

normalized_shape = rotated_shape.copy()

normalized_shape.scale(SCALE_FACTOR)

# Center again after scaling
normalized_shape.translate(
    stl_center.sub(normalized_shape.BoundBox.Center)
)

normalized_obj = doc.addObject(
    "Part::Feature",
    "Rotated_STEP_Normalized_Visual"
)

normalized_obj.Shape = normalized_shape

normalized_obj.ViewObject.ShapeColor = (0.1, 0.9, 0.2)
normalized_obj.ViewObject.Transparency = 55


# DISPLAY

doc.recompute()

# Show the STL and normalized STEP for easy visual comparison.
# The original-scale STEP remains available in the tree.
original_scale_obj.Visibility = False
normalized_obj.Visibility = True
stl_obj.Visibility = True

Gui.activeDocument().activeView().viewAxonometric()
Gui.activeDocument().activeView().fitAll()

print("\n========================================")
print("ORIENTATION CHECK READY")
print("========================================")
print("Visible: STL + normalized rotated STEP")
print("Hidden: original-scale rotated STEP")
print("Saved file:", OUTPUT_STEP)
print("\nToggle object visibility in the tree to inspect.")